install.packages("tidyverse")  # If not already installed
library(tidyverse)

df <- read.csv("D:/Python/4Assignment/Netflix_shows_movies/Netflix_data_cleaned.csv", stringsAsFactors = FALSE)

# Check the first few rows
head(df)


df_clean <- df %>%
  select(listed_in) %>%
  filter(!is.na(listed_in)) %>%
  separate_rows(listed_in, sep = ", ") %>%
  count(listed_in, name = "Count") %>%
  arrange(desc(Count))


ggplot(df_clean[1:10,], aes(x = reorder(listed_in, Count), y = Count, fill = listed_in)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Most Watched Genres", x = "Genre", y = "Count") +
  theme_minimal() +
  theme(legend.position = "none")