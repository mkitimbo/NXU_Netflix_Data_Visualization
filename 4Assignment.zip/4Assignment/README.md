# README

## Netflix Data Visualization

### Overview
This project is implemented using 2 separate scripts. The main tasks are executed within Jupyter Notebook running on VS Code IDE with file called 4 Netflix Data Visualization v3

When you run this script, you will be able to unzip the file

NOTE:   ORIGINAL FILE WAS NOT A ZIPPED FILE, I JUST ZIPPED IT FOR PURPOSES OF FULFILLING THE ASSIGNMENT REQUIREMENT
- import  necessary libraries
unzip and load the file
perform data exploration
data cleanup
data visualization code

You may choose to run code block by code block or simply execute the whole script.
Eitherway, it will yield the same results.

### Project Structure
Importing libraries and unziping the file provides
- All files are stored in the same zipped folder, so you will need to first unzip the file and place your folder into your desired directory
- you may update the hardcoded directories within the scripts for best results and not to run into errors.

### nstallation and Setup
- Python 3.13
- Required library: None (Uses built-in libraries)
- Clone the repository:
- Navigate to the project directory:
-Note: Take note of the variations within the IDEs. I used VS code with jupyter notebook within the VS code. plus the RStudio

### Code Explanation

###  PolicyHolder Class (policyholder.py)
The code is highly commented with all desired outputs and explanations of the output.


### . R Script

Run R integration.R script in Rstudio after running Python script as this script uses a cleaned file created by Python, jupyter notebook.


Expected Output:

I have tested the code more than 5 times and it is giving me the best desired results.

I can not say I have exhausted all the data exploratory analysis possible. There is room for more analysis.

The RStudio script provides an excellent visualization compared to what Python produces in my view.


### ISSUE
I would love to investigate further why calling R from within Python could make my python kernel crash all the time and often taking too long to execute.

### License
This project is open-source under the MIT License.
### Author
Moses Kitimbo